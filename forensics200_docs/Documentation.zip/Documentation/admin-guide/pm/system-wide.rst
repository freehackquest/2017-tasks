============================
System-Wide Power Management
============================

.. toctree::
   :maxdepth: 2

   sleep-states

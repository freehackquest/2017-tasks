================
Power Management
================

.. toctree::
   :maxdepth: 2

   strategies
   system-wide
   working-state

==============================
Working-State Power Management
==============================

.. toctree::
   :maxdepth: 2

   cpufreq
   intel_pstate
